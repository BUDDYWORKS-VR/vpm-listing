# BUDDYWORKS RipTrip

Take a little piss on avatar reuploaders, with this simple anti-reupload logic template!

**What it does:**
- Bully reuploaders from using the avatar.
- Is unlocked by specific toggle and slider values you decide, the unlock is saved so you don't have to deal with it again until you reset avatar.
- Runs locally, so won't bother other people, just the thief themselves.

**What it doesn't:**
- Defer people with knowledge to circumvent it.
- Encrypting things.
- Make manual rips impossible.

This is a very simple system to deter very low-skill avatar theft, nothing more. It is designed to be effective for that, while annoying you as the original owner as little as possible.

> *Should work on both PC and Android. *
> *Logic requires WD On, if you are on WD OFF you might need to rewrite it with that workflow in mind.*

**Only for personal avi's, do not ship on commercial avatars**

**Download**
<https://buddyworks.gumroad.com/l/brt>
<https://payhip.com/b/LHcUI>
<https://buddyworks.booth.pm/items/5288330>

**How to implement:**
`1. Use AV3Manager to merge the example FX and parameter to your avatar.

1.1 (optional): Rename the parameter in parameter list and FX to something else for obfuscation. Make sure to adjust "Trip!" parameter driver and the transition between Idle and "Rip?" in FX.

2. On the Transition between "Rip?" and "Trip!", define the conditions to unlock your avatar.

3. Supply your single animation clip payload into the "Rip?" state. I provide an example animation for reference. You can do whatever in this animation clip to annoy, I just deactivate all main meshes. Sky's the limit!

4. You're done, test in gesture manager and upload.

If you want to skip the unlocking while working on your avatar, just set the RipTrip parameter default to true until you are done.`

