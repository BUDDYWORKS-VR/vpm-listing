# unitypackage-icon-tool
Patch for the Unity Editor to allow adding icons to .unitypackages.
