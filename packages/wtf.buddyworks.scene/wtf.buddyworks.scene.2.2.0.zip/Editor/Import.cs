using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;
using UnityEditor.SceneManagement;

public class BuddyworksScene : MonoBehaviour
{
    [MenuItem("BUDDYWORKS/Avatar Scene/Add Scene Data")]
    static void CopyBuddyworksScene()
    {
        System.IO.Directory.CreateDirectory("Assets/BUDDYWORKS");
        FileUtil.CopyFileOrDirectory("Packages/wtf.buddyworks.scene/Avatar Scene", "Assets/BUDDYWORKS/Avatar Scene");
        AssetDatabase.Refresh();
        EditorSceneManager.SaveOpenScenes();
        EditorSceneManager.OpenScene("Assets/BUDDYWORKS/Avatar Scene/Avatar Scene.unity");
    }
    [MenuItem("BUDDYWORKS/Avatar Scene/Open Scene...")]
    static void OpenBuddyworksScene()
    {
        EditorSceneManager.SaveOpenScenes();
        EditorSceneManager.OpenScene("Assets/BUDDYWORKS/Avatar Scene/Avatar Scene.unity");
    }
}