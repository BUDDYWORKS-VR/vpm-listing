# BUDDYWORKS UnityPackage Icon Tool

Ever wondered how you could fancy up your unitypackages when people open them?

Wonder no more, with this simple tool!

Import the tool into the project you want to export from, and specify the image when you export your package.
Your icon selection is remembered on every export.

**Image Specifications**
- Low resolution. (should not exceed 128×128, it's small anyway.)
- Image should be squared, else it will be squished.

**Credits**

Tool created by [Dor](https://store.dor.dev) for BUDDYWORKS.
The tool's source code is published under GNU Lesser General Public Licence v3.0 and can be found on [GitHub](https://github.com/JustBuddy/unitypackage-icon-tool).

Enjoy ❤️

**Download**
https://repo.buddyworks.wtf/
