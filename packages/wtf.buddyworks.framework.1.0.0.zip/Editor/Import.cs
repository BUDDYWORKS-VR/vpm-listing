using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System.IO;

public class CopyFile : MonoBehaviour
{
    [MenuItem("BUDDYWORKS/Avatar Framework/Add v1 Template Files")]
    static void CopyFrameworkV1()
    {
        System.IO.Directory.CreateDirectory("Assets/BUDDYWORKS");
        FileUtil.CopyFileOrDirectory("Packages/wtf.buddyworks.framework/Avatar Framework/v1", "Assets/BUDDYWORKS/Avatar Framework");
        AssetDatabase.Refresh();
    }
    [MenuItem("BUDDYWORKS/Avatar Framework/Add v2 Template Files (Preview)")]
    static void CopyFrameworkV2()
    {
        System.IO.Directory.CreateDirectory("Assets/BUDDYWORKS");
        FileUtil.CopyFileOrDirectory("Packages/wtf.buddyworks.framework/Avatar Framework/v2", "Assets/BUDDYWORKS/Avatar Framework");
        AssetDatabase.Refresh();
    }
}