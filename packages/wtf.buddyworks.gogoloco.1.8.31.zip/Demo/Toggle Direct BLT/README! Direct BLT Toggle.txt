This an example of how you can combine all your toggles into one layer using Blend Tree.

The Blend Tree State needs to have Write Defaults ON. It won't create issues with the rest of the controller if OFF is used.

1 - ON/OFF something.

2 - Using Bool with of it.

3 - Using Int with about it.

4 - Color Radial.

5 - Transform Radial.

6 - Looping animation.


Read this documentation for more detail.

https://notes.sleightly.dev/dbt-combining/