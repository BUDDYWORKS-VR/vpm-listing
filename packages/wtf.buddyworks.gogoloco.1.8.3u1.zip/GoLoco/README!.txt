Version 1.8.3

Add VRCFury to your creator companion to use the auto instal prefab :

	https://vrcfury.com/

Social Link :

linktr.ee/franada